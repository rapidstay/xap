package com.rapidstay.xap.batch.job;

import com.rapidstay.xap.batch.job.tasklet.CityDataCollector;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@RequiredArgsConstructor
public class CityDataJobConfig {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final CityDataCollector cityDataCollector;

    @Bean
    public Job cityDataJob() {
        return new JobBuilder("cityDataJob", jobRepository)
                .start(cityDataStep())
                .build();
    }

    @Bean
    public Step cityDataStep() {
        return new StepBuilder("cityDataStep", jobRepository)
                .tasklet((contribution, chunkContext) -> {
                    System.out.println("🏙️ Starting CityDataCollector...");
                    cityDataCollector.runBatch(); // ✅ 실제 수집 실행
                    System.out.println("✅ CityDataCollector completed successfully!");
                    return RepeatStatus.FINISHED;
                }, transactionManager)
                .build();
    }
}
